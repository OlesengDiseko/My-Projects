using Firebase.Auth;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using StudentMarketPlace.Repository;
using StudentMarketPlace.Repository.Account;
using StudentMarketPlace.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddLogging(config =>
{
    config.AddConsole();
    config.AddDebug();
    // Add other logging providers as needed
});
builder.Services.AddSession(); // Add session support
builder.Services.AddHttpContextAccessor(); // Register IHttpContextAccessor
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logoff";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
    });

builder.Services.AddTransient<EmailService>();
builder.Services.AddHostedService<FirebaseInitializerService>();
builder.Services.AddSingleton<FirebaseConnect>(); // Ensure singleton instance for FirebaseConnect
builder.Services.AddScoped<IFirebaseAuthProvider>(provider => provider.GetService<FirebaseConnect>().authProvider);
builder.Services.AddScoped<FirestoreService>(); // Register FirestoreService
builder.Services.AddScoped<AccountRepository>(); // Register AccountRepository

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession(); // Ensure this line is included
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
