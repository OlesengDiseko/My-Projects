﻿namespace StudentMarketPlace.Models
{
    public class Buyer
    {
        public string Id { get; set; } // Firestore document ID
        public string Email { get; set; }
        public string Name { get; set; }
        public string StudentNumber { get; set; }
        public string Images { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
