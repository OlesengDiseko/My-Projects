﻿using Google.Cloud.Firestore;


namespace StudentMarketPlace.Models
{

    [FirestoreData]
    public class User
    {
        [FirestoreProperty]
        public string Id { get; set; }
        [FirestoreProperty]
        public string Name { get; set; }
        [FirestoreProperty]
        public string Surname { get; set; }
        [FirestoreProperty]
        public string EmailAddress { get; set; }
        [FirestoreProperty]
        public string Password { get; set; }
        [FirestoreProperty]
        public string Role { get; set; }
       // [FirestoreProperty]
        public string Images { get; set; }
       // [FirestoreProperty]

        public string StudentNumber { get; set; }
       // [FirestoreProperty]
        public string Email { get; set; }
    }


}
