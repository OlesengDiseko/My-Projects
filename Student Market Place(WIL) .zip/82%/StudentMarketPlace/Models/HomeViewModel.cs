﻿namespace StudentMarketPlace.Models
{
    public class HomeViewModel
    {
        public List<Item> Books { get; set; }
        public List<Item> Laptops { get; set; }
        public List<Item> Phones { get; set; }
        public List<Item> Watches { get; set; }
        public List<Item> Headphones { get; set; }
        public List<Item> AllItems { get; set; }


        public IEnumerable<Item> Products { get; set; }
        public bool ShowAllProducts { get; set; }
        public bool ShowAllBooks { get; set; }
        public bool ShowAllLaptops { get; set; }
        public bool ShowAllPhones { get; set; }
        public bool ShowAllWatches { get; set; }
        public bool ShowAllHeadphones { get; set; }
    }
}
