﻿using Google.Cloud.Firestore;

namespace StudentMarketPlace.Models
{
    [FirestoreData]
    public class Order
    {
        [FirestoreProperty]
        public string Id { get; set; }

        [FirestoreProperty]
        public string Email { get; set; }

        [FirestoreProperty]
        public string Image { get; set; }

        [FirestoreProperty]
        public string Name { get; set; }

        [FirestoreProperty]
        public string Price { get; set; }

        [FirestoreProperty]
        public string Product { get; set; }

        [FirestoreProperty]
        public string ProductImage { get; set; }
    }
}
