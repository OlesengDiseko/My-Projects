﻿using Google.Cloud.Firestore;

namespace StudentMarketPlace.Models
{
    [FirestoreData]
    public class Item
    {
        [FirestoreProperty]
        public string Id { get; set; }

        [FirestoreProperty]
        public string Name { get; set; }

        [FirestoreProperty]
        public string Image { get; set; }

        [FirestoreProperty]
        public string Price { get; set; }

        [FirestoreProperty]
        public string ProductDetail { get; set; }

        [FirestoreProperty]
        public string Quantity { get; set; }

        [FirestoreProperty]
        public string SearchKey { get; set; }

        [FirestoreProperty]
        public string UpdatedName { get; set; }

        //[FirestoreProperty]
        //public List<string> Variants { get; set; }

       // [FirestoreProperty]
        public string CollectionName { get; set; }
    }
}
