﻿using Google.Cloud.Firestore;

namespace StudentMarketPlace.Models
{
    [FirestoreData]
    public class Review
    {
        [FirestoreDocumentId]
        public string Id { get; set; }

        [FirestoreProperty("message")]
        public string Message { get; set; }

        [FirestoreProperty("title")]
        public string Title { get; set; }

        [FirestoreProperty("email")]
        public string email { get; set; }

        public bool CanEdit { get; set; }
    }
}
