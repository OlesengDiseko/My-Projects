﻿using Firebase.Auth;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.DependencyInjection;
using StudentMarketPlace.Repository;
using StudentMarketPlace.Repository.Account;
using StudentMarketPlace.Services;

namespace StudentMarketPlace
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<EmailService>();
            services.AddControllersWithViews();
            services.AddLogging(config =>
            {
                config.AddConsole();
                config.AddDebug();
                // Add other logging providers as needed
            });
            services.AddSession(); // Add session support
            services.AddHttpContextAccessor(); // Register IHttpContextAccessor
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options =>
                {
                    options.LoginPath = "/Account/Login";
                    options.LogoutPath = "/Account/Logoff";
                    options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
                });

            services.AddHostedService<FirebaseInitializerService>();
            services.AddSingleton<FirebaseConnect>(); // Ensure singleton instance for FirebaseConnect
            services.AddScoped<IFirebaseAuthProvider>(provider => provider.GetService<FirebaseConnect>().authProvider);
            services.AddScoped<FirestoreService>(); // Register FirestoreService
            services.AddScoped<AccountRepository>(); // Register AccountRepository
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseSession(); // Ensure this line is included
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
