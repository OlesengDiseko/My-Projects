﻿using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace StudentMarketPlace.Services
{
    public class FirebaseInitializerService : IHostedService
    {
        private readonly IConfiguration _configuration;

        public FirebaseInitializerService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            var credentialPath = Path.Combine(Directory.GetCurrentDirectory(), _configuration["Firebase:firebase-adminsdk.json"]);

            FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile(credentialPath)
            });

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
