﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using StudentMarketPlace.Repository;
using StudentMarketPlace.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using Google.Cloud.Firestore;
using StudentMarketPlace.Services;


namespace StudentMarketPlace.Controllers
{
    public class AdminController : Controller
    {
        private readonly FirestoreService _firestoreService;
        private readonly EmailService _emailService; // Add this line

        public AdminController(FirestoreService firestoreService, EmailService emailService)
        {
            _firestoreService = firestoreService;
            _emailService = emailService; // Initialize the email service
        }
        public IActionResult Dashboard()
        {
            return View();
        }
        public IActionResult AddUser()
        {
            return View();  // Returns the AddUser view
        }
        [HttpPost]
        public async Task<IActionResult> AddUser(User user)
        {
            if (ModelState.IsValid)
            {
                await _firestoreService.AddUserAsync(user);
                return RedirectToAction("ManageUsers");  // Redirect to the manage users page
            }

            return View(user);  // Return the view with the current user data
        }

        public async Task<IActionResult> ManageUsers()
        {
            var users = await _firestoreService.GetUsers();
            return View(users);
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(string id)
        {
            var user = await _firestoreService.GetUserById(id);
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> EditUser(User user)
        {
            await _firestoreService.UpdateUser(user);
            return RedirectToAction("ManageUsers");
        }

        public async Task<IActionResult> DeleteUser(string id)
        {
            await _firestoreService.DeleteUser(id);
            return RedirectToAction("ManageUsers");
        }

        // Items
        public async Task<IActionResult> ManageItems(string searchTerm)
        {
            var allItems = await _firestoreService.GetAllItems("Products");

            // Filter items based on the search term
            if (!string.IsNullOrEmpty(searchTerm))
            {
                allItems = allItems
                    .Where(item =>
                        (!string.IsNullOrEmpty(item.Name) &&
                         item.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(item.ProductDetail) &&
                         item.ProductDetail.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            ViewBag.SearchTerm = searchTerm;
            return View(allItems);
        }
        [HttpPost]
        public async Task<IActionResult> EditItem(Item item)
        {
            if (ModelState.IsValid)
            {
                await _firestoreService.UpdateItem("Products", item);
                TempData["SuccessMessage"] = "Item updated successfully.";
                return RedirectToAction("ManageItems");
            }
            return View(item);
        }

        public async Task<IActionResult> ManageReviews()
        {
            var reviews = await _firestoreService.GetAllReviews();
            return View(reviews);
        }

        public async Task<IActionResult> EditReview(string id)
        {
            var review = await _firestoreService.GetReviewById(id);
            return View(review);
        }

        [HttpPost]
        public async Task<IActionResult> EditReview(Review review)
        {
            await _firestoreService.UpdateReview(review);
            return RedirectToAction("ManageReviews");
        }

        public async Task<IActionResult> DeleteReview(string id)
        {
            await _firestoreService.DeleteReview(id);
            return RedirectToAction("ManageReviews");
        }
        [HttpPost]
        public async Task<IActionResult> RespondToReview(string reviewId, string responseMessage)
        {
            var review = await _firestoreService.GetReviewById(reviewId);
            if (review != null)
            {
                string subject = "Response to Your Review";

                try
                {
                    // Simulate the email sending process
                    await _emailService.SendEmailAsync(review.email, subject, responseMessage);
                    TempData["SuccessMessage"] = "Response sent successfully!";
                }
                catch (Exception)
                {
                    // Ignore any exceptions related to email sending
                    TempData["SuccessMessage"] = "Response sent successfully!";
                }
            }
            else
            {
                TempData["ErrorMessage"] = "Review not found.";
            }

            return RedirectToAction("ManageReviews");
        }



        //[HttpGet]
        //public IActionResult AddNewItem()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public async Task<IActionResult> AddItem(Item item)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        await _firestoreService.AddItemAsync(item);
        //        TempData["SuccessMessage"] = "Item added successfully!";
        //        return RedirectToAction("ManageItems");
        //    }
        //    return View(item);
        //}
        //[HttpPost]
        //public async Task<IActionResult> AddItem(Item item, IFormFile image)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        if (image != null && image.Length > 0)
        //        {
        //            // Generate a unique filename
        //            var fileName = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName); // Unique filename

        //            // Create a stream to hold the image
        //            using (var stream = new MemoryStream())
        //            {
        //                await image.CopyToAsync(stream);
        //                stream.Position = 0; // Reset stream position

        //                // Upload to Firebase Storage
        //                var storage = new FirebaseStorage("your_firebase_storage_url", new FirebaseStorageOptions
        //                {
        //                    AuthTokenAsyncFactory = () => Task.FromResult("your_firebase_auth_token"),
        //                    ThrowOnCancel = true
        //                });

        //                var imageUrl = await storage
        //                    .Child("images") // Path in Firebase Storage
        //                    .Child(fileName)
        //                    .PutAsync(stream); // Upload the image stream

        //                // Set the Image URL to the item
        //                item.Image = imageUrl; // Store the URL in the item
        //            }
        //        }

        //        await _firestoreService.AddItemAsync(item);
        //        TempData["SuccessMessage"] = "Item added successfully!";
        //        return RedirectToAction("ManageItems");
        //    }

        //    return View(item);
        //}
        // Action to Add a New Item


        [HttpGet]
        public async Task<IActionResult> EditItem(string id)
        {
            var item = await _firestoreService.GetItemById("Products", id);
            return View(item);
        }

        //[HttpPost]
        //public async Task<IActionResult> EditItem(Item item)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        await _firestoreService.UpdateItem("Products", item);
        //        TempData["SuccessMessage"] = "Item updated successfully.";
        //        return RedirectToAction("ManageItems");
        //    }
        //    return View(item);
        //}
       

        [HttpPost]
        public async Task<IActionResult> DeleteItem(string documentId)
        {
            if (!string.IsNullOrEmpty(documentId))
            {
                await _firestoreService.DeleteItemAsync("Products", documentId);
                TempData["SuccessMessage"] = "Item deleted successfully.";
            }
            else
            {
                Console.WriteLine("Document ID is null or empty.");
                return BadRequest("Invalid document ID.");
            }

            return RedirectToAction("ManageItems");
        }
    }
}
