﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StudentMarketPlace.Models;
using StudentMarketPlace.Repository;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace StudentMarketPlace.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly FirestoreService _firestoreService;

        public HomeController(ILogger<HomeController> logger, FirestoreService firestoreService)
        {
            _logger = logger;
            _firestoreService = firestoreService;
        }

        //public async Task<IActionResult> Index(string searchTerm, bool showAllBooks = false, bool showAllLaptops = false, bool showAllPhones = false, bool showAllWatches = false, bool showAllHeadphones = false)
        //{
        //    // Fetch items with search functionality
        //    var books = await _firestoreService.GetItemsAsync("Books", searchTerm);
        //    var laptops = await _firestoreService.GetItemsAsync("Laptop", searchTerm);
        //    var phones = await _firestoreService.GetItemsAsync("Phone", searchTerm);
        //    var watches = await _firestoreService.GetItemsAsync("Watch", searchTerm);
        //    var headphones = await _firestoreService.GetItemsAsync("HeadPhone", searchTerm);

        //    var allItems = books.Concat(laptops).Concat(phones).Concat(watches).Concat(headphones).ToList();

        //    // Pass the search term to the view for displaying it in the search box
        //    ViewBag.SearchTerm = searchTerm;

        //    // Create the view model for items
        //    var viewModel = new HomeViewModel
        //    {
        //        Books = showAllBooks ? books : books.Take(2).ToList(),
        //        Laptops = showAllLaptops ? laptops : laptops.Take(2).ToList(),
        //        Phones = showAllPhones ? phones : phones.Take(2).ToList(),
        //        Watches = showAllWatches ? watches : watches.Take(2).ToList(),
        //        Headphones = showAllHeadphones ? headphones : headphones.Take(2).ToList(),
        //        ShowAllBooks = showAllBooks,
        //        ShowAllLaptops = showAllLaptops,
        //        ShowAllPhones = showAllPhones,
        //        ShowAllWatches = showAllWatches,
        //        ShowAllHeadphones = showAllHeadphones,
        //        AllItems = allItems
        //    };

        //    return View(viewModel);
        //}
        public async Task<IActionResult> Index(string searchTerm)
        {
            var allItems = await _firestoreService.GetAllItems("Products");

            // If there's a search term, filter the items
            if (!string.IsNullOrEmpty(searchTerm))
            {
                allItems = allItems
                    .Where(item =>
                        (!string.IsNullOrEmpty(item.Name) &&
                         item.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(item.ProductDetail) &&
                         item.ProductDetail.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            var viewModel = new HomeViewModel
            {
                Products = allItems, // This should be a property in your HomeViewModel
                ShowAllProducts = false // Adjust based on your logic
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Books(string searchTerm)
        {
            var books = await _firestoreService.GetItemsAsync("Books", searchTerm);
            return View(books);
        }

        public async Task<IActionResult> Laptops(string searchTerm)
        {
            var laptops = await _firestoreService.GetItemsAsync("Laptop", searchTerm);
            return View(laptops);
        }
        public async Task<IActionResult> Watches(string searchTerm)
        {
            var watches = await _firestoreService.GetItemsAsync("Watch", searchTerm);
            return View(watches);
        }

        public async Task<IActionResult> Headphones(string searchTerm)
        {
            var laptops = await _firestoreService.GetItemsAsync("HeadPhone", searchTerm);
            return View(laptops);
        }
        public async Task<IActionResult> Phones(string searchTerm)
        {
            var phones = await _firestoreService.GetItemsAsync("Phone", searchTerm);
            return View(phones);
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SendMessage(string name, string email, string message)
        {
            // Logic for sending the message (e.g., save to database, send an email)
            TempData["SuccessMessage"] = "Your message has been sent successfully!";
            return RedirectToAction("ContactUs");
        }
        [HttpPost]
        public async Task<IActionResult> AddNewItem(Item model, string collectionName)
        {
            if (ModelState.IsValid)
            {
                var newItem = new Item
                {
                    Image = model.Image,
                    Name = model.Name,
                    Price = model.Price,
                    ProductDetail = model.ProductDetail,
                    Quantity = model.Quantity,
                    SearchKey = model.SearchKey,
                    UpdatedName = model.UpdatedName
                };

                await _firestoreService.AddItemAsync(collectionName, newItem);
                return RedirectToAction(collectionName); // Redirect to the specific collection view
            }

            // If model state is invalid, get the current items in the collection
            var items = await _firestoreService.GetAllItems(collectionName);
            return View(collectionName, items); // Pass the list of items back to the view
        }

        // Action to Delete an Item
        [HttpPost]
        public async Task<IActionResult> Delete(string id, string collectionName)
        {
            await _firestoreService.DeleteItemAsync(collectionName, id);
            return RedirectToAction("Headphones"); // Redirect to the specific collection view
        }
         [HttpGet]
        public IActionResult AddBook()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddBook(Item book)
        {
            if (ModelState.IsValid)
            {
                await _firestoreService.AddBookAsync(book);
                TempData["SuccessMessage"] = "Book added successfully.";
                return RedirectToAction("ManageBooks"); // Adjust this to your manage books view
            }
            return View(book);
        }


        public IActionResult ContactUs()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
