﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StudentMarketPlace.Models;
using StudentMarketPlace.Repository.Account;
using System;
using System.Threading.Tasks;

namespace StudentMarketPlace.Controllers
{
    public class AccountController : Controller
    {
        private readonly AccountRepository _accountRepository;
        private readonly ILogger<AccountController> _logger;

        public AccountController(AccountRepository accountRepository, ILogger<AccountController> logger)
        {
            _accountRepository = accountRepository;
            _logger = logger;
        }

        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> SignUp(SignUp signUp)
        {
            try
            {
                await _accountRepository.SignUp(signUp);
                ModelState.AddModelError(string.Empty, "A verification email has been sent to your email address.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Sign-up error for user {Email}", signUp.EmailAddress);
                ModelState.AddModelError(string.Empty, "An error occurred during sign-up. Please try again later.");
            }
            return View(signUp);
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            ViewData["ReturnUrl"] = returnUrl;  // Pass the returnUrl to the view
            if (this.User.Identity.IsAuthenticated)
            {
                return RedirectToLocal(returnUrl);
            }
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(Login login, string? returnUrl = null)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _logger.LogInformation("Attempting to log in user {Email}", login.EmailAddress);
                    var email = await _accountRepository.Login(login, HttpContext);
                    if (!string.IsNullOrEmpty(email))
                    {
                        var role = await _accountRepository.GetUserRole(email);
                        HttpContext.Session.SetString("Role", role);
                        _logger.LogInformation("{Role} {Email} logged in successfully", role, login.EmailAddress);

                        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                        {
                            return Redirect(returnUrl);
                        }

                        return RedirectToAction(role == "Admin" ? "Dashboard" : "Index", role == "Admin" ? "Admin" : "Home");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Login failed for user {Email}", login.EmailAddress);
                    ModelState.AddModelError(string.Empty, "Invalid login credentials. Please check your email and password.");
                }
            }
            return View(login);
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult LogOff()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> ForgotPassword(string emailID)
        {
            try
            {
                await _accountRepository.PasswordResetLink(emailID);
                ModelState.AddModelError(string.Empty, "A reset password link has been sent to your email address.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Password reset error for user {Email}", emailID);
                ModelState.AddModelError(string.Empty, "An error occurred while sending the reset link. Please try again later.");
            }
            return View();
        }
    }
}
