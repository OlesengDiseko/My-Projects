﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace StudentMarketPlace.Controllers
{
    public class ContactController : Controller
    {
        [HttpPost]
        public async Task<IActionResult> SendMessage(string name, string email, string message)
        {
            // Simulate sending a message and return a success message
            ViewBag.SuccessMessage = "Your message has been sent successfully!";
            return View("Contact"); // Return to the Contact view with a success message
        }

        public IActionResult Contact()
        {
            return View(); // Your contact form view
        }
    }
}
