﻿using System;

namespace StudentMarketPlace.Repository.DataConnection
{
    public class FirebaseConstants
    {
        public static string Web_ApiKey = "AIzaSyCiyZCHLMy-8XSqTW5W9NVsZ_x8WOSd9rk";
        public static string Auth_Domain = "cutstudentshop.firebaseapp.com";
        public static string DatabaseUrl = "https://cutstudentshop-default-rtdb.firebaseio.com/";
        public static string FromMail = "sndlovu37306@gmail.com";
        public static string ResponseMessageEmailTemplate = @"/EmailTemplate/ResponseMessageTemplate.txt";
    }
}
