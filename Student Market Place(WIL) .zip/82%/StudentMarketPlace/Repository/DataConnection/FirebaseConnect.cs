﻿using Firebase.Auth;
//using Firebase.Auth.Providers;
using Google.Cloud.Firestore;
using StudentMarketPlace.Repository.DataConnection;
using System;

namespace StudentMarketPlace.Repository
{
    public class FirebaseConnect : IDisposable
    {
        public FirestoreDb firestoreDb { get; private set; }
        public IFirebaseAuthProvider authProvider { get; private set; }

        public FirebaseConnect()
        {
            var path = Path.Combine(AppContext.BaseDirectory, "cutstudentshopsk.json"); // Use relative path from root
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            firestoreDb = FirestoreDb.Create("cutstudentshop"); // Replace with your Firestore project ID

            authProvider = new FirebaseAuthProvider(new FirebaseConfig(FirebaseConstants.Web_ApiKey)); // Use your API key
        }

        public void Dispose()
        {
            this.Dispose(); // Dispose resources if needed
        }
    }
}
