﻿//using Google.Cloud.Firestore;
//using StudentMarketPlace.Models;
//using System.Collections.Generic;
//using System.Threading.Tasks;

//namespace StudentMarketPlace.Repository.Account
//{
//    public class AdminService
//    {
//        private readonly FirestoreDb _firestoreDb;

//        public AdminService(FirebaseConnect firebaseConnect)
//        {
//            _firestoreDb = firebaseConnect.firestoreDb;
//        }
        

//        public async Task<List<User>> GetUsers()
//        {
//            Query query = _firestoreDb.Collection("Users");
//            QuerySnapshot snapshot = await query.GetSnapshotAsync();
//            List<User> users = new List<User>();

//            foreach (var doc in snapshot.Documents)
//            {
//                if (doc.Exists)
//                {
//                    users.Add(doc.ConvertTo<User>());
//                }
//            }

//            return users;
//        }

//        public async Task<User> GetUserById(string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Users").Document(id);
//            DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
//            return snapshot.ConvertTo<User>();
//        }

//        public async Task UpdateUser(User user)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Users").Document(user.EmailAddress);
//            await docRef.SetAsync(user);
//        }

//        public async Task DeleteUser(string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Users").Document(id);
//            await docRef.DeleteAsync();
//        }

//        // Items
//        public async Task<Item> GetItemById(string collection, string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection(collection).Document(id);
//            DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
//            return snapshot.ConvertTo<Item>();
//        }

//        public async Task UpdateItem(string collection, Item item)
//        {
//            DocumentReference docRef = _firestoreDb.Collection(collection).Document(item.Id); // Assuming Id is unique
//            await docRef.SetAsync(item);
//        }

//        public async Task DeleteItem(string collection, string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection(collection).Document(id);
//            await docRef.DeleteAsync();
//        }

//        // Reviews
//        public async Task<List<Review>> GetAllReviews()
//        {
//            Query query = _firestoreDb.Collection("Reviews");
//            QuerySnapshot snapshot = await query.GetSnapshotAsync();
//            List<Review> reviews = new List<Review>();

//            foreach (var doc in snapshot.Documents)
//            {
//                if (doc.Exists)
//                {
//                    reviews.Add(doc.ConvertTo<Review>());
//                }
//            }

//            return reviews;
//        }

//        public async Task<Review> GetReviewById(string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(id);
//            DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
//            return snapshot.ConvertTo<Review>();
//        }

//        public async Task UpdateReview(Review review)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(review.Id);
//            await docRef.SetAsync(review);
//        }

//        public async Task DeleteReview(string id)
//        {
//            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(id);
//            await docRef.DeleteAsync();
//        }
//    }
//}

