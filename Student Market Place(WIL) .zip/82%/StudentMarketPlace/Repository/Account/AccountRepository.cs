﻿using Google.Cloud.Firestore;
using StudentMarketPlace.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;
using Firebase.Auth;

namespace StudentMarketPlace.Repository.Account
{
    public class AccountRepository : IDisposable
    {
        private readonly FirestoreDb _firestoreDb;
        private readonly IFirebaseAuthProvider _authProvider;

        public AccountRepository()
        {
            var connect = new FirebaseConnect();
            _firestoreDb = connect.firestoreDb;
            _authProvider = connect.authProvider;
        }

        public async Task SignUp(SignUp signUp)
        {
            try
            {
                var authLink = await _authProvider.CreateUserWithEmailAndPasswordAsync(
                    signUp.EmailAddress, signUp.Password, signUp.Name, true);

                var user = new StudentMarketPlace.Models.User
                {
                    Id = authLink.User.LocalId,
                    Name = signUp.Name,
                    Surname = signUp.Surname,
                    EmailAddress = signUp.EmailAddress,
                    Password = signUp.Password, // Note: Hash passwords in a real application
                    Role = "Admin" // Default role
                };
                DocumentReference docRef = _firestoreDb.Collection("Users").Document(user.Id);
                await docRef.SetAsync(user);
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred during sign-up. Please try again.", ex);
            }
        }

        public async Task<string> Login(Login login, HttpContext httpContext)
        {
            try
            {
                var authLink = await _authProvider.SignInWithEmailAndPasswordAsync(login.EmailAddress, login.Password);
                if (authLink != null)
                {
                    var userQuery = _firestoreDb.Collection("Users").WhereEqualTo("EmailAddress", login.EmailAddress);
                    var snapshot = await userQuery.GetSnapshotAsync();
                    if (snapshot.Documents.Count == 1)
                    {
                        var user = snapshot.Documents[0].ConvertTo<StudentMarketPlace.Models.User>();
                        httpContext.Session.SetString("EmailAddress", login.EmailAddress);
                        httpContext.Session.SetString("Role", user.Role);
                        return login.EmailAddress;
                    }
                }
                throw new Exception("Invalid login credentials.");
            }
            catch (Exception ex)
            {
                throw new Exception("Login failed: " + ex.Message, ex);
            }
        }

        public async Task<bool> IsAdmin(string email)
        {
            var query = _firestoreDb.Collection("Admin").WhereEqualTo("EmailAddress", email);
            var snapshot = await query.GetSnapshotAsync();
            return snapshot.Documents.Any();
        }

        public async Task<string> GetUserRole(string email)
        {
            var query = _firestoreDb.Collection("Users").WhereEqualTo("EmailAddress", email);
            var snapshot = await query.GetSnapshotAsync();
            if (snapshot.Documents.Count == 1)
            {
                var user = snapshot.Documents[0].ConvertTo<StudentMarketPlace.Models.User>();
                return user.Role;
            }
            return null;
        }

        public async Task PasswordResetLink(string emailID)
        {
            await _authProvider.SendPasswordResetEmailAsync(emailID);
        }

        public void Dispose()
        {
            // Dispose resources if needed
        }
    }
}
