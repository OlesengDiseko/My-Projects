﻿using Google.Cloud.Firestore;
using StudentMarketPlace.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StudentMarketPlace.Repository
{
    public class FirestoreService
    {
        private readonly FirestoreDb _firestoreDb;

        public FirestoreService(FirebaseConnect firebaseConnect)
        {
            _firestoreDb = firebaseConnect.firestoreDb;
        }

        // User Management
        public async Task AddUserAsync(User user)
        {
            var userCollection = _firestoreDb.Collection("user");
            await userCollection.Document().SetAsync(new
            {
                Email = user.Email,
                Name = user.Name,
                StudentNumber = user.StudentNumber,
                //RegisteredAt = FieldValue.ServerTimestamp // Automatically capture timestamp
            });
        }

        public async Task<List<User>> GetUsers()
        {
            Query query = _firestoreDb.Collection("user");
            QuerySnapshot snapshot = await query.GetSnapshotAsync();
            List<User> users = new List<User>();

            foreach (var doc in snapshot.Documents)
            {
                if (doc.Exists)
                {
                    users.Add(doc.ConvertTo<User>());
                }
            }

            return users;
        }

        public async Task<User> GetUserById(string id)
        {
            DocumentReference docRef = _firestoreDb.Collection("user").Document(id);
            DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
            return snapshot.Exists ? snapshot.ConvertTo<User>() : null;
        }

        public async Task UpdateUser(User user)
        {
            DocumentReference docRef = _firestoreDb.Collection("user").Document(user.Email);
            await docRef.SetAsync(user);
        }

        public async Task DeleteUser(string id)
        {
            DocumentReference docRef = _firestoreDb.Collection("user").Document(id);
            await docRef.DeleteAsync();
        }

        // Item Management
        public async Task AddItemAsync(string collectionName, Item item)
        {
            try
            {
                // Generate a new document reference with an auto-generated ID
                var documentRef = _firestoreDb.Collection(collectionName).Document();

                // Set the item data to the new document
                await documentRef.SetAsync(new
                {
                    item.Image,
                    item.Name,
                    item.Price,
                    item.ProductDetail,
                    item.Quantity,
                    item.SearchKey,
                    item.UpdatedName
                });

                item.Id = documentRef.Id; // Store the document ID in the item object if needed
                Console.WriteLine("Item added successfully!");
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error adding item: {ex.Message}");
            }
        }
        public async Task<List<Item>> GetAllItems(string collectionName)
        {
            var items = new List<Item>();
            var snapshot = await _firestoreDb.Collection(collectionName).GetSnapshotAsync();

            foreach (var document in snapshot.Documents)
            {
                var item = document.ConvertTo<Item>();
                item.Id = document.Id;
                items.Add(item);
            }

            return items;
        }

        public async Task<Item> GetItemById(string collectionName, string id)
        {
            var docRef = _firestoreDb.Collection(collectionName).Document(id);
            var snapshot = await docRef.GetSnapshotAsync();
            return snapshot.Exists ? snapshot.ConvertTo<Item>() : null;
        }

        public async Task UpdateItem(string collectionName, Item item)
        {
            var docRef = _firestoreDb.Collection(collectionName).Document(item.Id);
            await docRef.SetAsync(item);
        }

        public async Task DeleteItemAsync(string collectionName, string documentId)
        {
            var docRef = _firestoreDb.Collection(collectionName).Document(documentId);
            await docRef.DeleteAsync();
        }
        public async Task AddBookAsync(Item book)
        {
            var documentRef = _firestoreDb.Collection("Books").Document();
            await documentRef.SetAsync(book);
            book.Id = documentRef.Id; // Store the document ID in the item object if needed
            Console.WriteLine("Book added successfully!");
        }

        // Review Management
        public async Task<List<Review>> GetAllReviews()
        {
            Query query = _firestoreDb.Collection("Reviews");
            QuerySnapshot snapshot = await query.GetSnapshotAsync();
            List<Review> reviews = new List<Review>();

            foreach (var doc in snapshot.Documents)
            {
                if (doc.Exists)
                {
                    var review = doc.ConvertTo<Review>();
                    review.Id = doc.Id;
                    reviews.Add(review);
                }
            }

            return reviews;
        }

        public async Task<Review> GetReviewById(string id)
        {
            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(id);
            DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
            return snapshot.Exists ? snapshot.ConvertTo<Review>() : null;
        }

        public async Task UpdateReview(Review review)
        {
            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(review.Id);
            await docRef.SetAsync(review);
        }

        public async Task DeleteReview(string id)
        {
            DocumentReference docRef = _firestoreDb.Collection("Reviews").Document(id);
            await docRef.DeleteAsync();
        }

        // Search items
        public async Task<List<Item>> GetItemsAsync(string collectionName, string searchTerm)
        {
            Query query = _firestoreDb.Collection(collectionName);
            QuerySnapshot snapshot = await query.GetSnapshotAsync();
            List<Item> items = new List<Item>();

            foreach (var doc in snapshot.Documents)
            {
                if (doc.Exists)
                {
                    var item = doc.ConvertTo<Item>();

                    if (string.IsNullOrEmpty(searchTerm) ||
                        (!string.IsNullOrEmpty(item.Name) && item.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                        (!string.IsNullOrEmpty(item.ProductDetail) && item.ProductDetail.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)))
                    {
                        item.CollectionName = collectionName;
                        items.Add(item);
                    }
                }
            }

            return items;
        }
    }
}
